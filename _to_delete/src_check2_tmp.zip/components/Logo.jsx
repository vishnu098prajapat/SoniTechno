/**
 * Recreated from the SoniTechno logo:
 * a bold black "S" mark with a red slash, "Soni" in red + "Techno" in black,
 * and the tagline "a complete IT solution".
 */
export default function Logo({ light = false, compact = false }) {
  return (
    <div className="flex items-center gap-3">
      <svg viewBox="0 0 44 48" className="h-10 w-9 shrink-0" aria-hidden="true">
        {/* red slash behind the S */}
        <path d="M27 2 13 46" stroke="#e62e2e" strokeWidth="7" strokeLinecap="round" />
        {/* the S mark */}
        <path
          d="M33 11c-3.4-3.6-8-5.4-13-5.4C13.6 5.6 9 9 9 14.2c0 4.6 3.3 7 10.6 8.9 7.9 2 12.4 4.9 12.4 11.1 0 6.2-5.4 10.4-13.3 10.4-5.6 0-10.4-1.9-13.7-5.6"
          fill="none"
          stroke={light ? '#ffffff' : '#0a0a0c'}
          strokeWidth="6.5"
          strokeLinecap="round"
        />
      </svg>

      <div className="leading-none">
        <p className="font-sans text-[1.3rem] font-extrabold">
          <span className="text-brand-500">Soni</span>
          <span className={light ? 'text-white' : 'text-ink-950'}>Techno</span>
        </p>
        {!compact && (
          <p className={`mt-1.5 text-[9.5px] font-semibold tracking-[0.16em] ${light ? 'text-white/45' : 'text-ink-300'}`}>
            a complete IT solution
          </p>
        )}
      </div>
    </div>
  )
}
