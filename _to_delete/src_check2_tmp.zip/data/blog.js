/**
 * Blog content.
 * Post list, categories and tags follow sonitechno.com/blog-grid.aspx and blog-single.aspx.
 * Images are served locally from public/images/blog/.
 */
const IMG = '/images/blog' // kept for reference; paths below are written out in full

export const categories = [
  'Business',
  'IT Solutions',
  'IT Development',
  'Data Security',
  'Startup Professionals',
  'Digital Marketing',
  'Strategies',
]

export const popularTags = [
  'IT Solutions',
  'Business',
  'Security',
  'Power & Energy',
  'IT Services',
  'Digital',
  'Software',
  'Marketing',
]

export const posts = [
  {
    slug: 'efficient-measurable-benefits-of-software',
    title: '10 Efficient & Measurable Benefits of Software',
    category: 'IT Projects',
    date: '24 June 2019',
    author: 'Admin',
    readTime: '6 min read',
    image: '/images/blog/Benifit.jpg',
    excerpt:
      'Custom software is not an expense line — it is a set of measurable gains. Here are the ten benefits we see repeat across every project we deliver.',
    quote:
      'We are committed to providing quality IT Services — our benefits are endless for local IT companies and startups. We really know the true needs and expectations of customers.',
    tags: ['Case Studies', 'Business', 'IT Services'],
    body: [
      {
        heading: 'Software should pay for itself',
        paragraphs: [
          'Every business owner who approaches us asks the same question in some form: what do I actually get back? It is a fair question, and the honest answer is that good software returns value in ways you can put a number against — hours saved, errors avoided, transactions that no longer need a human to complete.',
          'The ten benefits below are the ones our clients report most often after going live. None of them are theoretical; each is something you can measure before and after.',
        ],
      },
      {
        heading: 'The ten benefits',
        list: [
          'Manual work disappears — recharges, settlements and reports that took hours run on their own.',
          'Fewer human errors, because the rules live in the system rather than in someone’s memory.',
          'Faster turnaround for your customers, which directly affects repeat business.',
          'Live visibility — you can see today’s numbers today, not at month end.',
          'Every action leaves an audit trail, which makes reconciliation and disputes straightforward.',
          'The platform grows with you: more retailers or more services do not mean more staff.',
          'Your brand stays on the product, not a vendor’s, because everything we build is white label.',
          'Lower running costs once the repetitive work is automated.',
          'Compliance rules are enforced by the software instead of being checked by hand.',
          'You own the system, so you are never locked in to someone else’s roadmap or pricing.',
        ],
      },
      {
        heading: 'How to measure it',
        paragraphs: [
          'Pick three numbers before development starts — typically time per transaction, error rate and monthly operating cost. Record them honestly. Six weeks after launch, record them again.',
          'In our experience the biggest surprise is rarely the cost saving. It is how much faster a team moves once nobody is waiting on a spreadsheet.',
        ],
      },
    ],
  },

  {
    slug: 'native-or-cross-platform-mobile-development',
    title: 'Native or Cross-Platform: Mobile Development',
    category: 'Mobile Apps',
    date: '24 June 2019',
    author: 'Admin',
    readTime: '5 min read',
    image: '/images/blog/App_dev.jpg',
    excerpt:
      'The native versus cross-platform argument has no universal winner. It has a right answer for your app, your budget and your timeline.',
    quote:
      'Choose native when the hardware is the product. Choose cross-platform when the screens are the product.',
    tags: ['Mobile Apps', 'Development', 'Strategies'],
    body: [
      {
        heading: 'What actually separates the two',
        paragraphs: [
          'A native app is written for one platform in that platform’s own language — Kotlin or Java for Android, Swift for iOS. A cross-platform app is written once and compiled for both.',
          'The trade is straightforward: native gives you the deepest access to the device and the smoothest possible feel; cross-platform gives you one codebase, one team and roughly half the build time.',
        ],
      },
      {
        heading: 'When we recommend native',
        list: [
          'The app leans on hardware — biometric capture for AEPS, card readers, camera-heavy flows.',
          'Performance is the feature: heavy animation, real-time graphics, large offline datasets.',
          'You need a new OS capability on the day it ships rather than months later.',
        ],
      },
      {
        heading: 'When we recommend cross-platform',
        list: [
          'The app is mostly forms, lists and dashboards — which describes most retailer and distributor panels.',
          'You need Android and iOS live at the same time, with one team maintaining both.',
          'The budget is fixed and you would rather spend it on features than on building the same screen twice.',
        ],
      },
      {
        heading: 'Our default',
        paragraphs: [
          'For recharge, money transfer and booking portals we usually start cross-platform, because those apps are dominated by screens and API calls rather than by device hardware. Where a biometric or peripheral requirement appears, we build that one piece natively and bridge it.',
          'The decision is reversible if you plan for it. Keep your business logic on the server, and swapping the shell later costs far less than people expect.',
        ],
      },
    ],
  },

  {
    slug: 'vital-tips-for-blockchain-software-product',
    title: 'Vital Tips For Blockchain Software Product',
    category: 'Development',
    date: '24 June 2019',
    author: 'Admin',
    readTime: '5 min read',
    image: '/images/blog/Blockchain.jpg',
    excerpt:
      'Most blockchain projects fail for ordinary reasons — unclear problem, wrong data on-chain, no plan for keys. These are the checks worth doing first.',
    quote:
      'If a shared database with good permissions would solve the problem, use the shared database.',
    tags: ['Development', 'Security', 'Software'],
    body: [
      {
        heading: 'Start with the problem, not the technology',
        paragraphs: [
          'The first question is whether you need a ledger that no single party controls. If every participant in your process already trusts one operator — and in most businesses they do — a conventional database is faster, cheaper and easier to fix.',
          'Blockchain earns its place when several parties who do not fully trust each other must agree on the same record.',
        ],
      },
      {
        heading: 'Keep personal data off the chain',
        paragraphs: [
          'Anything written to a chain is effectively permanent. That is precisely the wrong property for names, phone numbers, Aadhaar or PAN details.',
          'Store personal data in your own system and put only a hash on the chain. You keep the proof of integrity without publishing anything you might later be required to delete.',
        ],
      },
      {
        heading: 'Practical checks before you build',
        list: [
          'Decide who holds the private keys, and what happens the day one is lost.',
          'Estimate transaction cost at ten times your expected volume, not at today’s.',
          'Plan the upgrade path — contracts are hard to change after deployment.',
          'Get the contract audited by someone who did not write it.',
          'Build a normal admin interface. Users should never need to understand the chain.',
        ],
      },
    ],
  },

  {
    slug: 'data-security-with-multiple-business-values',
    title: 'Data Security with multiple business values',
    category: 'Security News',
    date: '24 June 2019',
    author: 'Admin',
    readTime: '6 min read',
    image: '/images/blog/data_security.jpg',
    excerpt:
      'Security is usually discussed as a cost. In a transaction business it is closer to inventory — protect it and the whole operation runs; lose it and everything stops.',
    quote:
      'A breach in a payments business is not an IT incident. It is a business continuity event.',
    tags: ['Data Security', 'Business', 'IT Solutions'],
    body: [
      {
        heading: 'Why it matters more in fintech',
        paragraphs: [
          'When your platform moves money, security failures are not abstract. A compromised retailer login can drain a wallet in minutes, and the loss lands on you long before it lands on anyone else.',
          'This is why every portal we build ships with the controls below turned on by default, rather than offered as paid extras.',
        ],
      },
      {
        heading: 'The controls we build in',
        list: [
          'MAC and IP based access, so a login only works from approved devices and networks.',
          'OTP verification on every sensitive operation — fund transfer, wallet adjustment, role change.',
          'Captcha and multi-step verification at the point of entry.',
          'Role-based permissions across admin, distributor and retailer levels.',
          'A complete audit trail: who did what, from where, and when.',
          'Encrypted storage for credentials and transaction records.',
        ],
      },
      {
        heading: 'The business value',
        paragraphs: [
          'Good security is not only about avoiding loss. Distributors sign up faster when the panel visibly protects their float. Banking partners ask fewer questions during onboarding. Disputes resolve in minutes because the log answers them.',
          'Treat it as a feature you can sell, and the spend justifies itself.',
        ],
      },
    ],
  },

  {
    slug: 'leverage-the-full-spectrum-of-technology-stacks',
    title: 'Leverage the full spectrum of technology stacks',
    category: 'IT Sector News',
    date: '24 June 2019',
    author: 'Admin',
    readTime: '5 min read',
    image: '/images/blog/Levrage.jpg',
    excerpt:
      'No single stack is right for everything. The skill is matching the tool to the layer — and keeping the seams between them clean.',
    quote:
      'Boring technology in the places that must never fail; new technology where it buys you speed.',
    tags: ['IT Sector News', 'Software', 'Strategies'],
    body: [
      {
        heading: 'One product, several stacks',
        paragraphs: [
          'A recharge platform is not one system. It is a public website, an admin panel, a retailer app, a settlement engine and a set of operator integrations — and each of those has different demands.',
          'Trying to force all of it through one framework usually means at least one layer is badly served.',
        ],
      },
      {
        heading: 'How we split it',
        list: [
          'Marketing site: static-first and SEO-friendly, so it loads fast on a weak connection.',
          'Admin and retailer panels: a component-driven front end, because these screens change constantly.',
          'Transaction core: a conservative, well-understood backend — this layer must be predictable above all.',
          'Integrations: isolated services per operator, so one provider’s outage cannot take down the rest.',
          'Reporting: read replicas, so heavy queries never slow down live transactions.',
        ],
      },
      {
        heading: 'Keep the seams clean',
        paragraphs: [
          'The real cost of a mixed stack is not learning several tools. It is the mess at the boundaries between them.',
          'We keep every boundary an explicit, versioned API. That way any single piece can be replaced years later without rewriting the rest of the platform.',
        ],
      },
    ],
  },

  {
    slug: 'commercial-apps-multi-platform-and-multi-device',
    title: 'Commercial apps multi-platform and multi-device',
    category: 'Development',
    date: '24 June 2019',
    author: 'Admin',
    readTime: '5 min read',
    image: '/images/blog/Commercial_app.jpg',
    excerpt:
      'Your retailer opens the panel on a budget Android phone. Your distributor uses a laptop. Your accountant uses a tablet. All three are the same product.',
    quote:
      'Design for the smallest screen and the slowest connection. Everything above that is easy.',
    tags: ['Development', 'Digital', 'IT Services'],
    body: [
      {
        heading: 'The device mix is wider than you think',
        paragraphs: [
          'A multitude of different screen sizes exist across phones, phablets, tablets, desktops and everything in between — and in a distributor network you will meet most of them in the first month.',
          'Because screen dimensions keep changing, a commercial app has to be built with the adaptability to work on formats that do not exist yet.',
        ],
      },
      {
        heading: 'What multi-device really requires',
        list: [
          'Fluid layouts rather than fixed breakpoints tuned to today’s popular handsets.',
          'Touch targets large enough for a retailer working quickly at a counter.',
          'Tables that stay readable when they collapse to a narrow screen.',
          'Offline tolerance — a dropped connection should not lose a transaction.',
          'Assets sized for slow networks, not for an office fibre line.',
        ],
      },
      {
        heading: 'One codebase, many contexts',
        paragraphs: [
          'The goal is not identical screens everywhere. It is the same capability everywhere, presented in the way that fits the device in the user’s hand.',
          'Get this right and support calls drop sharply, because nobody has to be told which device the panel "works properly" on.',
        ],
      },
    ],
  },
]

export const getPost = (slug) => posts.find((p) => p.slug === slug)
export const otherPosts = (slug, n = 3) => posts.filter((p) => p.slug !== slug).slice(0, n)
