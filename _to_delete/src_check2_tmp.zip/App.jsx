import { Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Home from './pages/Home.jsx'
import About from './pages/About.jsx'
import Contact from './pages/Contact.jsx'
import Blog from './pages/Blog.jsx'
import BlogPost from './pages/BlogPost.jsx'
import Privacy from './pages/Privacy.jsx'
import Reviews from './pages/Reviews.jsx'
import ServicePage from './pages/ServicePage.jsx'
import NotFound from './pages/NotFound.jsx'
import Demo from './pages/Demo.jsx'

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="about" element={<About />} />
        <Route path="contact" element={<Contact />} />
        <Route path="blog" element={<Blog />} />
        <Route path="blog/:slug" element={<BlogPost />} />
        <Route path="privacy" element={<Privacy />} />
        <Route path="reviews" element={<Reviews />} />
        <Route path="demo" element={<Demo />} />
        <Route path="it-solutions/:slug" element={<ServicePage />} />
        <Route path="software/:slug" element={<ServicePage />} />
        <Route path="api/:slug" element={<ServicePage />} />
        <Route path="services" element={<Navigate to="/it-solutions/website-development" replace />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  )
}
