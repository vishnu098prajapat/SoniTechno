import { Link } from 'react-router-dom'
import { site } from '../data/site.js'
import { IconArrow, IconPhone } from './Icons.jsx'

const galleryImages = [
  { src: '/images/pages/Recharge_api_.jpg', alt: 'Recharge API', rotate: '-rotate-[24deg]', pos: '-left-4 sm:left-2 lg:left-8 top-12 lg:top-10' },
  { src: '/images/pages/web_degine_and_dev.jpg', alt: 'Web Design', rotate: '-rotate-[14deg]', pos: 'left-16 sm:left-24 lg:left-44 top-4 lg:top-2' },
  { src: '/images/pages/payment_gatway.jpg', alt: 'Payment Gateway', rotate: '-rotate-[6deg]', pos: 'left-36 sm:left-48 lg:left-[27rem] -top-2 lg:-top-4' },
  { src: '/images/pages/Bill_payment_api.jpg', alt: 'Bill Payment', rotate: 'rotate-[6deg]', pos: 'right-36 sm:right-48 lg:right-[27rem] -top-2 lg:-top-4' },
  { src: '/images/pages/Pen_api.jpg', alt: 'Pan Card API', rotate: 'rotate-[14deg]', pos: 'right-16 sm:right-24 lg:right-44 top-4 lg:top-2' },
  { src: '/images/pages/APP_Development.jpg', alt: 'App Development', rotate: 'rotate-[24deg]', pos: '-right-4 sm:right-2 lg:right-8 top-12 lg:top-10' },
]

export default function CTA() {
  return (
    <section className="container-x py-16 sm:py-24 overflow-hidden">
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-b from-slate-900 via-ink-950 to-slate-950 px-6 py-20 text-white sm:px-12 sm:py-28 shadow-2xl border border-slate-800/80">
        
        {/* Glow effects */}
        <div className="pointer-events-none absolute left-1/2 -top-24 h-96 w-[36rem] -translate-x-1/2 rounded-full bg-brand-500/15 blur-[120px]" />
        <div className="pointer-events-none absolute inset-0 grid-lines-dark opacity-30" />

        {/* Arch Image Gallery (Hidden on very small screens, visible & responsive from sm up) */}
        <div className="pointer-events-none absolute inset-x-0 top-0 h-64 overflow-hidden hidden sm:block">
          <div className="relative mx-auto max-w-7xl h-full">
            {galleryImages.map((img, i) => (
              <div
                key={i}
                className={`pointer-events-auto absolute ${img.pos} ${img.rotate} transition-all duration-500 hover:z-30 hover:rotate-0 hover:scale-110 group`}
              >
                <div className="relative h-24 w-20 sm:h-32 sm:w-28 lg:h-40 lg:w-36 overflow-hidden rounded-2xl border-2 border-white/20 bg-slate-800 shadow-2xl transition-all duration-300 group-hover:border-brand-500 group-hover:shadow-brand-500/30">
                  <img
                    src={img.src}
                    alt={img.alt}
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent opacity-0 transition-opacity group-hover:opacity-100" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Content Box */}
        <div className="relative z-20 mx-auto max-w-3xl text-center sm:mt-16 lg:mt-20">
          <div className="flex justify-center">
            <span className="label label-light shadow-lg">Let's build it</span>
          </div>

          <h2 className="mt-6 font-extrabold tracking-tight text-balance text-[2rem] leading-[1.2] text-white sm:text-[3rem] sm:leading-[1.15]">
            Do You Need Our IT Solutions? <br className="hidden sm:block" />
            <span className="accent-serif font-medium text-brand-400">Get advice</span> from our professionals.
          </h2>

          <p className="mt-5 mx-auto max-w-lg text-[15px] sm:text-[1.0625rem] leading-relaxed text-slate-300">
            Got any questions? Call us today — we'll be happy to assist and help your business grow.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link to="/contact" className="btn-primary w-full sm:w-auto px-8 py-4 shadow-xl shadow-brand-500/25">
              Make a Request <IconArrow className="h-4 w-4" />
            </Link>
            <a
              href={`tel:${site.phones[0].replace(/\s/g, '')}`}
              className="w-full sm:w-auto px-8 py-4 flex items-center justify-center gap-2 rounded-full border border-slate-700 bg-slate-800/80 text-[14px] font-bold text-white transition-all hover:bg-slate-700 hover:border-slate-600 shadow-lg"
            >
              <IconPhone className="h-4 w-4 text-brand-400" /> Talk With Expert
            </a>
          </div>
        </div>

      </div>
    </section>
  )
}

