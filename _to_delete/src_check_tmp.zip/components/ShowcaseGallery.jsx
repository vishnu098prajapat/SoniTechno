import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { IconArrow, IconCheck } from './Icons.jsx'
import { pagePath } from '../data/index.js'

const showcaseItems = [
  {
    id: 'recharge',
    badge: '01. Multi Recharge Software',
    shortLabel: 'Recharge API',
    title: 'High-Speed Recharge & Bill Payment Portal',
    subtitle: 'Lightning fast transactions with 99.9% uptime and multi-operator support.',
    description: 'Empower your retailer network with our high-volume recharge API and white-label portal. Features automatic retry, instant commission settlement, and live operator status monitoring.',
    features: ['Instant Auto-Recharge API', 'Multi-Operator Support', 'Real-time Margin & Ledger', '24/7 Auto Refund System'],
    image: '/images/pages/Recharge_api_.jpg',
    link: pagePath('mobile-recharge-software'),
  },
  {
    id: 'payment',
    badge: '02. Payment Gateway Integration',
    shortLabel: 'Payment Gateway',
    title: 'Secure Multi-Channel Payment Gateway',
    subtitle: 'Accept UPI, Credit Cards, NetBanking, and Wallets with zero drop rates.',
    description: 'Complete merchant payment solutions designed for high concurrency. Integrated fraud detection, instant settlement options, and seamless developer-friendly API integration.',
    features: ['UPI QR & Intent Pay', 'Instant Payout API', 'Bank-Grade 256-bit Security', 'Detailed Analytics Dashboard'],
    image: '/images/pages/payment_gatway.jpg',
    link: pagePath('payment-gateway'),
  },
  {
    id: 'aeps',
    badge: '03. AEPS & Micro ATM API',
    shortLabel: 'AEPS & ATM',
    title: 'Banking & Financial Inclusion Services',
    subtitle: 'Turn every local shop into a mini bank branch with cash withdrawal & deposit.',
    description: 'Aadhaar Enabled Payment System (AEPS) and Micro ATM API integration. Enables biometric cash withdrawal, balance inquiry, mini statements, and Aadhaar Pay instantly.',
    features: ['Biometric Cash Withdrawal', 'Micro ATM Device SDK', 'Aadhaar Pay Integration', 'Real-time Bank Settlement'],
    image: '/images/pages/aeps_api.png',
    link: pagePath('aeps-api'),
  },
  {
    id: 'utility',
    badge: '04. Utility & BBPS Services',
    shortLabel: 'Utility BBPS',
    title: 'Bharat BillPay (BBPS) Integration',
    subtitle: 'One-stop bill payments for Electricity, Water, Gas, DTH & Fastag.',
    description: 'Connect directly to the BBPS network for fetching and paying utility bills across India, with instant bill receipt generation and commission tracking.',
    features: ['100+ Biller Connectivity', 'Instant Bill Fetch', 'BBPS Certified Solution', 'Automated Commission Credit'],
    image: '/images/pages/Bill_payment_api.jpg',
    link: pagePath('bbps'),
  },
  {
    id: 'webdev',
    badge: '05. Custom Web & App Development',
    shortLabel: 'Web & Mobile App',
    title: 'Bespoke Software & Mobile Applications',
    subtitle: 'Tailor-made portals, admin dashboards, and Android/iOS apps.',
    description: 'From initial UI/UX architecture to final cloud deployment, we build ultra-fast, responsive web applications and mobile apps tailored specifically to your business model.',
    features: ['Custom Admin Dashboards', 'Android & iOS Native/Hybrid', 'Scalable Microservices API', 'Dedicated Maintenance Support'],
    image: '/images/pages/web_degine_and_dev.jpg',
    link: pagePath('website-development'),
  },
]

export default function ShowcaseGallery() {
  const [activeIndex, setActiveIndex] = useState(0)
  const activeItem = showcaseItems[activeIndex]

  // Auto rotate every 6s unless hovered/interacted with, or user prefers reduced motion
  const [isPaused, setIsPaused] = useState(false)
  useEffect(() => {
    if (isPaused) return
    if (window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    const interval = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % showcaseItems.length)
    }, 6000)
    return () => clearInterval(interval)
  }, [isPaused])

  // Arc positioning angles for 5 items
  const angles = [-38, -19, 0, 19, 38]

  return (
    <section className="relative overflow-hidden bg-ink-950 py-20 sm:py-28 text-white">
      {/* Subtle brand-red glow background */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(230,46,46,0.16),transparent_50%)]" />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_right,rgba(230,46,46,0.08),transparent_50%)]" />
      <div className="pointer-events-none absolute inset-0 grid-lines-dark opacity-20" />

      <div className="w-full px-6 lg:px-12 relative z-10 mx-auto max-w-7xl">

        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 sm:mb-20">
          <div className="flex justify-center">
            <span className="label label-light">Interactive Showcase</span>
          </div>
          <h2 className="mt-4 display text-[2rem] sm:text-[2.75rem] font-extrabold tracking-tight text-white leading-tight">
            Explore Our <span className="bg-gradient-to-r from-brand-400 via-brand-500 to-brand-300 bg-clip-text text-transparent">Core IT Solutions</span>
          </h2>
          <p className="mt-3 text-[15px] sm:text-[1.0625rem] text-slate-400">
            Click on any solution from the interactive curved gallery to view complete details.
          </p>
        </div>

        {/* Showcase Grid Layout */}
        <div
          className="grid grid-cols-1 lg:grid-cols-[420px_1fr] xl:grid-cols-[460px_1fr] gap-12 lg:gap-16 items-center"
          onMouseEnter={() => setIsPaused(true)}
          onMouseLeave={() => setIsPaused(false)}
        >
          {/* LEFT SIDE: CURVED ARC WHEEL */}
          <div className="relative flex justify-center items-center h-[380px] sm:h-[460px] lg:h-[500px]">
            {/* The Arc Curve SVG Line background */}
            <svg
              className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-[420px] w-[420px] pointer-events-none opacity-30 text-brand-500"
              viewBox="0 0 420 420"
              fill="none"
            >
              <circle
                cx="80"
                cy="210"
                r="180"
                stroke="currentColor"
                strokeWidth="2"
                strokeDasharray="6 6"
              />
            </svg>

            {/* Arc Items Container */}
            <div className="relative w-full h-full flex items-center justify-center">
              {showcaseItems.map((item, idx) => {
                const isActive = idx === activeIndex
                const offset = idx - activeIndex
                const angle = angles[idx]

                // Calculate position along arc
                const translateY = offset * 76
                const translateX = Math.cos((angle * Math.PI) / 180) * 120 - 90
                const rotateDeg = offset * 12

                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveIndex(idx)}
                    aria-label={`Select ${item.title}`}
                    aria-pressed={isActive}
                    style={{
                      transform: `translate(${translateX}px, ${translateY}px) rotate(${rotateDeg}deg)`,
                      transition: 'all 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)',
                    }}
                    className={`group absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 flex items-center gap-4 rounded-2xl p-2 sm:p-2.5 transition-all duration-500 ${
                      isActive
                        ? 'z-30 scale-110 bg-ink-900/90 border-2 border-brand-500 shadow-red backdrop-blur-xl'
                        : 'z-10 bg-ink-900/50 border border-slate-800 hover:border-slate-700 opacity-60 hover:opacity-100 hover:scale-105'
                    }`}
                  >
                    {/* Thumbnail Image */}
                    <div className="relative h-14 w-14 sm:h-16 sm:w-16 shrink-0 overflow-hidden rounded-xl bg-slate-800">
                      <img
                        src={item.image}
                        alt={item.title}
                        className={`h-full w-full object-cover transition-transform duration-500 ${
                          isActive ? 'scale-110' : 'group-hover:scale-105'
                        }`}
                      />
                      {isActive && (
                        <span className="absolute inset-0 bg-brand-500/10 ring-2 ring-brand-500 inset-ring" />
                      )}
                    </div>

                    {/* Short Title on Card */}
                    <div className="text-left pr-4 min-w-[140px] sm:min-w-[170px]">
                      <span className={`block text-[11px] font-bold uppercase tracking-wider ${isActive ? 'text-brand-400' : 'text-slate-400'}`}>
                        {item.badge}
                      </span>
                      <p className={`text-[13px] sm:text-[14px] font-bold line-clamp-1 ${isActive ? 'text-white' : 'text-slate-300'}`}>
                        {item.shortLabel}
                      </p>
                    </div>

                    {/* Active Indicator Pulse */}
                    {isActive && (
                      <span className="mr-2 relative flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-brand-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-brand-500"></span>
                      </span>
                    )}
                  </button>
                )
              })}
            </div>
          </div>

          {/* RIGHT SIDE: DYNAMIC DETAILS PANEL */}
          <div className="relative rounded-3xl border border-slate-800 bg-ink-900/60 p-8 sm:p-10 backdrop-blur-xl shadow-2xl overflow-hidden min-h-[440px] flex flex-col justify-between">
            {/* Glowing Accent line */}
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-brand-600 via-brand-500 to-brand-300 transition-all duration-700" />

            <div>
              {/* Badge & Number */}
              <div className="flex items-center justify-between border-b border-slate-800/80 pb-4">
                <span className="text-[12px] font-bold uppercase tracking-[0.2em] text-brand-400">
                  {activeItem.badge}
                </span>
                <span className="font-mono text-sm font-semibold text-slate-400">
                  0{activeIndex + 1} / 0{showcaseItems.length}
                </span>
              </div>

              {/* Title & Subtitle */}
              <div key={activeItem.id} className="mt-6 animate-fadeUp">
                <h3 className="text-[1.65rem] sm:text-[2.2rem] font-extrabold text-white leading-tight tracking-tight">
                  {activeItem.title}
                </h3>
                <p className="mt-2 text-[14px] sm:text-[15px] font-semibold text-brand-300">
                  {activeItem.subtitle}
                </p>
                <p className="mt-4 text-[14.5px] sm:text-[15.5px] leading-relaxed text-slate-300 font-normal">
                  {activeItem.description}
                </p>
              </div>

              {/* Feature Points */}
              <div key={`feat-${activeItem.id}`} className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-3.5 animate-fadeUp">
                {activeItem.features.map((feat) => (
                  <div key={feat} className="flex items-center gap-3 rounded-xl bg-ink-800/50 p-3 border border-slate-700/50">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-brand-500/15 text-brand-400">
                      <IconCheck className="h-3.5 w-3.5" />
                    </span>
                    <span className="text-[13.5px] font-medium text-slate-200">{feat}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="mt-10 pt-6 border-t border-slate-800/80 flex flex-wrap items-center gap-4">
              <Link
                to={activeItem.link}
                className="btn-primary px-7 py-3.5 text-[14px] font-bold"
              >
                Explore Solution <IconArrow className="h-4 w-4" />
              </Link>
              <Link
                to="/contact"
                className="rounded-full border border-slate-700 bg-slate-800/60 px-7 py-3.5 text-[14px] font-bold text-white transition-all hover:bg-slate-700 hover:border-slate-600"
              >
                Request Demo
              </Link>
            </div>
          </div>

        </div>

      </div>
    </section>
  )
}
